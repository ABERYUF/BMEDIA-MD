// commands/kick.js (ESM)
// ✅ Owner-only kick (JID-only, no LID)
// Usage:
//   !kick @user
//   !kick 2376xxxxxxx
//   Reply to user + !kick

import { isOwner } from "../checks/isOwner.js";
import { normalizeJid, numberToUserJid, isGroupJid } from "../utils/jid.js";

function normalizeUserJid(anyId) {
  const s = String(anyId || "").trim();
  if (!s) return "";
  if (s.includes("@")) return normalizeJid(s);
  return normalizeJid(numberToUserJid(s));
}

function pickTargetJid(m, args) {
  // mention
  const mentioned = m?.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
  if (Array.isArray(mentioned) && mentioned[0]) {
    const j = normalizeUserJid(mentioned[0]);
    if (j) return j;
  }

  // reply participant
  const replied =
    m?.message?.extendedTextMessage?.contextInfo?.participant ||
    m?.message?.imageMessage?.contextInfo?.participant ||
    m?.message?.videoMessage?.contextInfo?.participant ||
    m?.message?.documentMessage?.contextInfo?.participant ||
    "";
  const r = normalizeUserJid(replied);
  if (r) return r;

  // typed
  const typed = normalizeUserJid((args || []).join(" ").trim());
  if (typed) return typed;

  return "";
}

function getBotJid(sock) {
  return normalizeJid(sock?.user?.id || sock?.user?.jid || "");
}

function looksLikeNotAdmin(errText) {
  const t = String(errText || "").toLowerCase();
  return t.includes("not-authorized") || t.includes("not authorized") || t.includes("forbidden") || t.includes("insufficient") || t.includes("admin");
}

export default {
  name: "kick",
  aliases: ["remove"],
  category: "OWNER",
  description: "Owner-only remove a member.",

  async execute(ctx) {
    const { sock, m, from, args, prefix } = ctx;

    if (!isGroupJid(from)) {
      return sock.sendMessage(from, { text: "❌ This command works in groups only." }, { quoted: m });
    }

    const ok = await isOwner(m, sock);
    if (!ok) {
      return sock.sendMessage(from, { text: "❌ Owner only." }, { quoted: m });
    }

    const target = pickTargetJid(m, args);
    if (!target) {
      return sock.sendMessage(
        from,
        { text: `Usage:\n${prefix}kick @user\n${prefix}kick 2376xxxxxxx\n(or reply to a user then ${prefix}kick)` },
        { quoted: m }
      );
    }

    const botJid = getBotJid(sock);
    if (target === botJid) {
      return sock.sendMessage(from, { text: "❌ I can't kick myself." }, { quoted: m });
    }

    try {
      await sock.groupParticipantsUpdate(from, [target], "remove");
      return sock.sendMessage(from, { text: "✅ Target removed." }, { quoted: m });
    } catch (e) {
      const lastErr = String(e?.message || e || "");
      if (looksLikeNotAdmin(lastErr)) {
        return sock.sendMessage(from, { text: "❌ I must be an admin to kick users." }, { quoted: m });
      }
      return sock.sendMessage(from, { text: `❌ Kick failed: ${lastErr.slice(0, 220)}` }, { quoted: m });
    }
  },
};
