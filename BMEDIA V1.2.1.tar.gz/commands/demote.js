export default {
  name: "demote",
  aliases: [],
  category: "GROUP",
  description: "Demote a member (admins only).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ demote executed.` }, { quoted: m });
  }
};
