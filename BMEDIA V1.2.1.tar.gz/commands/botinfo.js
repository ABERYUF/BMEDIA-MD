export default {
  name: "botinfo",
  aliases: [],
  category: "INFO",
  description: "Show bot information.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ botinfo executed.` }, { quoted: m });
  }
};
