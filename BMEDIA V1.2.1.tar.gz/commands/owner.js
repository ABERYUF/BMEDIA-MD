export default {
  name: "owner",
  aliases: [],
  category: "INFO",
  description: "Show owner contact.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ owner executed.` }, { quoted: m });
  }
};
