export default {
  name: "calcvat",
  aliases: [],
  category: "TOOLS",
  description: "Compute VAT given price and rate.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ calcvat executed.` }, { quoted: m });
  }
};
