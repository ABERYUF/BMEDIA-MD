export default {
  name: "say",
  aliases: [],
  category: "TOOLS",
  description: "Make bot repeat your text.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ say executed.` }, { quoted: m });
  }
};
