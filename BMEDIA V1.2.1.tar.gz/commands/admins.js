// commands/tagadmins.js (ESM)

// Usage: !tagadmins <optional message>

// Mentions all group admins and lists them as 1,2,3.

function numFromJid(jid) {

  return String(jid || "").split("@")[0];

}

export default {

  name: "admins",

  aliases: ["tagadmin", "mentionadmins"],

  category: "GROUP",

  description: "Mention all group admins (listed 1,2,3).",

  async execute(ctx) {

    const { sock, m, from, args } = ctx;

    if (!from || !from.endsWith("@g.us")) {

      return sock.sendMessage(

        from,

        { text: "This command works in groups only." },

        { quoted: m }

      );

    }

    const note = (args || []).join(" ").trim();

    try {

      const meta = await sock.groupMetadata(from);

      const participants = Array.isArray(meta?.participants) ? meta.participants : [];

      const admins = participants

        .filter((p) => p.admin === "admin" || p.admin === "superadmin")

        .map((p) => p.id)

        .filter(Boolean);

      if (!admins.length) {

        return sock.sendMessage(

          from,

          { text: "No admins found in this group." },

          { quoted: m }

        );

      }

      const list = admins

        .map((jid, i) => `${i + 1}. @${numFromJid(jid)}`)

        .join("\n");

      const text =

        `🛡️ *Group Admins*` +

        (note ? `\n${note}` : "") +

        `\n\n${list}`;

      return sock.sendMessage(from, { text, mentions: admins }, { quoted: m });

    } catch (e) {

      return sock.sendMessage(

        from,

        { text: `❌ Failed: ${e?.message || e}` },

        { quoted: m }

      );

    }

  },

};