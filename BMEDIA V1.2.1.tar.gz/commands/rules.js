export default {
  name: "rules",
  aliases: [],
  category: "INFO",
  description: "Show group rules placeholder.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `📌 Group rules: Be respectful. No spam. No scams.` }, { quoted: m });
  }
};
