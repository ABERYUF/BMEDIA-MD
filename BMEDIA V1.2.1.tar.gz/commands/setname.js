export default {
  name: "setname",
  aliases: [],
  category: "GROUP",
  description: "Set group subject (admins only).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ setname executed.` }, { quoted: m });
  }
};
