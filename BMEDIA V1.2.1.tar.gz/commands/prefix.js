// commands/prefix.js (ESM)
// Owner-only command to set bot prefix. Persists to ./control/config.json
//
// Usage:
//   <prefix>prefix <newPrefix>
//   <prefix>prefix off|none|null|noprefix   (sets no-prefix mode)
//   <prefix>prefix reset                    (delete stored prefix; fall back to .env)
//
// Stores "prefix" as a string. Empty string "" means no prefix.

import fs from "fs";
import path from "path";

const CONTROL_DIR = path.resolve(process.cwd(), "control");
const CONFIG_FILE = path.join(CONTROL_DIR, "config.json");

function readJsonSafe(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    const raw = fs.readFileSync(file, "utf-8");
    if (!raw?.trim()) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function writeJsonSafe(file, obj) {
  try {
    if (!fs.existsSync(CONTROL_DIR)) fs.mkdirSync(CONTROL_DIR, { recursive: true });
    fs.writeFileSync(file, JSON.stringify(obj, null, 2));
    return true;
  } catch {
    return false;
  }
}

function deleteFileSafe(file) {
  try {
    if (fs.existsSync(file)) fs.unlinkSync(file);
    return true;
  } catch {
    return false;
  }
}

function getText(m) {
  return String(
    m?.message?.conversation ||
      m?.message?.extendedTextMessage?.text ||
      m?.message?.imageMessage?.caption ||
      m?.message?.videoMessage?.caption ||
      ""
  ).trim();
}

function parseArgs(text) {
  // split by whitespace; keep everything after command as one string
  const parts = text.split(/\s+/);
  const cmd = parts.shift() || "";
  const rest = parts.join(" ").trim();
  return { cmd, rest };
}

function normalizePrefixInput(input) {
  const raw = (input ?? "").toString();
  const t = raw.trim();
  if (!t) return null;

  // Allow quoted empty string to explicitly set no-prefix: prefix ""
  if (t === '""' || t === "''") return "";

  const low = t.toLowerCase();
  if (["off", "none", "null", "noprefix", "no-prefix", "0"].includes(low)) return "";
  if (low === "reset") return "__RESET__";

  // If user types something like `!` or `.` or multi-char like `#` / `>>`
  // Keep as-is (but collapse surrounding quotes if provided)
  if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'"))) {
    return t.slice(1, -1);
  }

  return t;
}

export default {
  name: "prefix",
  aliases: ["setprefix"],
  category: "OWNER",
  description: "Set bot prefix and persist to control/config.json",

  async execute(ctx) {
    const { sock, m, from, senderJid, isOwner } = ctx;

    if (typeof isOwner === "function" && !isOwner({ senderJid })) {
      await sock.sendMessage(from, { text: "❌ Owner only." }, { quoted: m });
      return;
    }

    const text = getText(m);
    const { rest } = parseArgs(text);
    const wanted = normalizePrefixInput(rest);

    // Show current (config overrides env)
    const currentCfg = readJsonSafe(CONFIG_FILE, {});
    const current = typeof currentCfg?.prefix === "string" ? currentCfg.prefix : null;
    const envDefault = (process.env.PREFIX ?? "!").toString();

    if (wanted === null) {
      const effective = current !== null ? current : envDefault;
      await sock.sendMessage(
        from,
        {
          text:
            `⚙️ Current prefix: ${effective === "" ? "(no prefix)" : `\`${effective}\``}\n` +
            `Use:\n` +
            `• ${effective === "" ? "prefix" : effective + "prefix"} <newPrefix>\n` +
            `• ${effective === "" ? "prefix" : effective + "prefix"} off|none|null|noprefix\n` +
            `• ${effective === "" ? "prefix" : effective + "prefix"} reset`
        },
        { quoted: m }
      );
      return;
    }

    if (wanted === "__RESET__") {
      const ok = deleteFileSafe(CONFIG_FILE);
      await sock.sendMessage(
        from,
        { text: ok ? `✅ Prefix reset. Using default from .env: \`${envDefault}\`` : "❌ Failed to reset prefix." },
        { quoted: m }
      );
      return;
    }

    // Save
    const next = {
      ...(typeof currentCfg === "object" && currentCfg ? currentCfg : {}),
      prefix: wanted, // empty string allowed
      updatedAt: Date.now()
    };

    const ok = writeJsonSafe(CONFIG_FILE, next);
    if (!ok) {
      await sock.sendMessage(from, { text: "❌ Failed to save prefix." }, { quoted: m });
      return;
    }

    await sock.sendMessage(
      from,
      { text: `✅ Prefix set to: ${wanted === "" ? "(no prefix)" : `\`${wanted}\``}` },
      { quoted: m }
    );
  }
};
