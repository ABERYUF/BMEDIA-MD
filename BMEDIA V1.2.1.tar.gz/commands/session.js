export default {
  name: "session",
  aliases: [],
  category: "OWNER",
  description: "Backup creds.json (owner).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ session executed.` }, { quoted: m });
  }
};
