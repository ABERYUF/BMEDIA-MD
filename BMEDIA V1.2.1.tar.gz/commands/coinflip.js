export default {
  name: "coinflip",
  aliases: [],
  category: "FUN",
  description: "Flip a coin.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ coinflip executed.` }, { quoted: m });
  }
};
