export default {
  name: "broadcast",
  aliases: [],
  category: "OWNER",
  description: "Broadcast message (owner).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ broadcast executed.` }, { quoted: m });
  }
};
