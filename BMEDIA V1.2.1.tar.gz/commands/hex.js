export default {
  name: "hex",
  aliases: [],
  category: "TOOLS",
  description: "Encode/decode hex.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ hex executed.` }, { quoted: m });
  }
};
