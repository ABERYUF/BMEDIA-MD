const QUOTES=["Discipline beats motivation.", "Small steps every day add up.", "Consistency is a superpower.", "You learn by building."];
export default {name:"quote",aliases:["quotes"],category:"FUN",description:"Random quote.",async execute(ctx){const {sock,m,from}=ctx;const q=QUOTES[Math.floor(Math.random()*QUOTES.length)];return sock.sendMessage(from,{text:`💬 ${q}`},{quoted:m});}};
