export default {
  name: "time",
  aliases: [],
  category: "TOOLS",
  description: "Show server time.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ time executed.` }, { quoted: m });
  }
};
