export default {
  name: "compliment",
  aliases: [],
  category: "FUN",
  description: "Give a compliment.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ compliment executed.` }, { quoted: m });
  }
};
