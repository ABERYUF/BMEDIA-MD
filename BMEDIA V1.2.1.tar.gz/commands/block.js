export default {
  name: "block",
  aliases: [],
  category: "OWNER",
  description: "Block user (owner).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ block executed.` }, { quoted: m });
  }
};
