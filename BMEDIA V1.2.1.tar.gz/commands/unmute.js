export default {
  name: "unmute",
  aliases: [],
  category: "GROUP",
  description: "Unmute group (admins only).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ unmute executed.` }, { quoted: m });
  }
};
