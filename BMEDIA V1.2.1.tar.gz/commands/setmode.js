export default {
  name: "setmode",
  aliases: [],
  category: "OWNER",
  description: "Set mode (owner).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ setmode executed.` }, { quoted: m });
  }
};
