export default {
  name: "mute",
  aliases: [],
  category: "GROUP",
  description: "Mute group (admins only).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ mute executed.` }, { quoted: m });
  }
};
