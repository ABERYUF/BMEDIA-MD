// commands/gemini.js (ESM)

// Uses ElitePro API endpoint to generate a reply.

// Usage: !gemini <message>

// Reply: sends only the "text" field from API response.

async function safeFetch(url, opts) {

  if (globalThis.fetch) return fetch(url, opts);

  const mod = await import("node-fetch"); // fallback if your Node lacks fetch

  return mod.default(url, opts);

}

export default {

  name: "copilot",

  aliases: ["ai", "ask"],

  category: "AI",

  description: "Chat with Copilot.",

  async execute(ctx) {

    const { sock, m, from, args, prefix } = ctx;

    const prompt = (args || []).join(" ").trim();

    if (!prompt) {

      return sock.sendMessage(

        from,

        { text: `Usage: ${prefix}gemini <your message>` },

        { quoted: m }

      );

    }

    // Endpoint from your screenshot

    const endpoint = "https://eliteprotech-apis.zone.id/copilot";

    const url = `${endpoint}?message=${encodeURIComponent(prompt)}`;

    try {

      // Optional: show "typing…" if your base supports it

      try { await sock.sendPresenceUpdate?.("composing", from); } catch {}

      const res = await safeFetch(url, {

        method: "GET",

        headers: {

          "accept": "application/json",

        },

      });

      if (!res.ok) {

        return sock.sendMessage(

          from,

          { text: `❌ API error (${res.status}). Try again.` },

          { quoted: m }

        );

      }

      const data = await res.json().catch(() => null);

      const text = data?.text ? String(data.text).trim() : "";

      if (!text) {

        return sock.sendMessage(

          from,

          { text: "❌ API returned no text. Try again." },

          { quoted: m }

        );

      }

      return sock.sendMessage(from, { text }, { quoted: m });

    } catch (e) {

      return sock.sendMessage(

        from,

        { text: `❌ Failed: ${e?.message || e}` },

        { quoted: m }

      );

    } finally {

      try { await sock.sendPresenceUpdate?.("paused", from); } catch {}

    }

  },

};