// commands/tagall.js (ESM)

// Usage: !tagall <optional message>

// Mentions all members and lists them as 1,2,3.

// Splits into chunks to avoid WhatsApp mention limits.

function chunk(arr, size) {

  const out = [];

  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));

  return out;

}

function numFromJid(jid) {

  return String(jid || "").split("@")[0];

}

export default {

  name: "tagall",

  aliases: ["everyone", "alltag", "mentionall"],

  category: "GROUP",

  description: "Mention all group members (listed 1,2,3).",

  async execute(ctx) {

    const { sock, m, from, args } = ctx;

    if (!from || !from.endsWith("@g.us")) {

      return sock.sendMessage(

        from,

        { text: "This command works in groups only." },

        { quoted: m }

      );

    }

    const note = (args || []).join(" ").trim();

    try {

      const meta = await sock.groupMetadata(from);

      const members = (Array.isArray(meta?.participants) ? meta.participants : [])

        .map((p) => p.id)

        .filter(Boolean);

      if (!members.length) {

        return sock.sendMessage(

          from,

          { text: "No participants found." },

          { quoted: m }

        );

      }

      const batchSize = 40;

      const batches = chunk(members, batchSize);

      for (let b = 0; b < batches.length; b++) {

        const batch = batches[b];

        const list = batch

          .map((jid, i) => `${b * batchSize + i + 1}. @${numFromJid(jid)}`)

          .join("\n");

        const text =

          `📢 *Tag All*` +

          (note && b === 0 ? `\n${note}` : "") +

          `\n\n${list}` +

          (batches.length > 1 ? `\n\n(${b + 1}/${batches.length})` : "");

        await sock.sendMessage(

          from,

          { text, mentions: batch },

          { quoted: b === 0 ? m : undefined }

        );

      }

    } catch (e) {

      return sock.sendMessage(

        from,

        { text: `❌ Failed: ${e?.message || e}` },

        { quoted: m }

      );

    }

  },

};