export default {
  name: "promote",
  aliases: [],
  category: "GROUP",
  description: "Promote a member (admins only).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ promote executed.` }, { quoted: m });
  }
};
