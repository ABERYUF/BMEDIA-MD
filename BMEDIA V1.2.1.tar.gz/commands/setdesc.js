export default {
  name: "setdesc",
  aliases: [],
  category: "GROUP",
  description: "Set group description (admins only).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ setdesc executed.` }, { quoted: m });
  }
};
