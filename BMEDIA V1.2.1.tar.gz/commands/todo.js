export default {
  name: "todo",
  aliases: [],
  category: "TOOLS",
  description: "Simple todo list (local).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ todo executed.` }, { quoted: m });
  }
};
