export default {
  name: "base64",
  aliases: [],
  category: "TOOLS",
  description: "Encode/decode base64.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ base64 executed.` }, { quoted: m });
  }
};
