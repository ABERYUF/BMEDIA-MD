export default {
  name: "snipe",
  aliases: [],
  category: "TOOLS",
  description: "Show last deleted message (not implemented).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `❌ Not implemented.` }, { quoted: m });
  }
};
