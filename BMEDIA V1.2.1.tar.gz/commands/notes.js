export default {
  name: "notes",
  aliases: [],
  category: "TOOLS",
  description: "Save/read notes (local).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ notes executed.` }, { quoted: m });
  }
};
