export default {
  name: "8ball",
  aliases: [],
  category: "FUN",
  description: "Magic 8-ball.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ 8ball executed.` }, { quoted: m });
  }
};
