export default {
  name: "echo",
  aliases: [],
  category: "TOOLS",
  description: "Echo with formatting.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ echo executed.` }, { quoted: m });
  }
};
