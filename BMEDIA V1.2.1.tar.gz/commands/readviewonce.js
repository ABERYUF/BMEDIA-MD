export default {
  name: "readviewonce",
  aliases: [],
  category: "MEDIA",
  description: "Read view-once (not supported).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `❌ Not supported for privacy/safety.` }, { quoted: m });
  }
};
