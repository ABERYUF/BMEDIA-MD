export default {
  name: "profile",
  aliases: [],
  category: "TOOLS",
  description: "Show your profile info.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ profile executed.` }, { quoted: m });
  }
};
