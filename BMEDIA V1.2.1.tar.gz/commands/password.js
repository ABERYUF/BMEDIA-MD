export default {
  name: "password",
  aliases: [],
  category: "TOOLS",
  description: "Generate a password.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ password executed.` }, { quoted: m });
  }
};
