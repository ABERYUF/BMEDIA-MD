export default {
  name: "mathquiz",
  aliases: [],
  category: "FUN",
  description: "Simple math quiz.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ mathquiz executed.` }, { quoted: m });
  }
};
