// commands/hidetag.js (ESM)

// Usage: !hidetag <message>

// Sends a message while mentioning all group members (no admin required).

// The mentions are "hidden" because we don't print @numbers; we only pass `mentions`.

export default {

  name: "hidetag",

  aliases: ["ht", "hdt", "taghidden"],

  category: "GROUP",

  description: "Mention all members without showing the @list (no admin required).",

  async execute(ctx) {

    const { sock, m, from, args, prefix } = ctx;

    if (!from?.endsWith("@g.us")) {

      return sock.sendMessage(from, { text: "This command works in groups only." }, { quoted: m });

    }

    const message = (args || []).join(" ").trim();

    if (!message) {

      return sock.sendMessage(

        from,

        { text: `Usage: ${prefix}hidetag <message>` },

        { quoted: m }

      );

    }

    try {

      const meta = await sock.groupMetadata(from);

      const mentions = (meta?.participants || []).map((p) => p.id).filter(Boolean);

      if (!mentions.length) {

        return sock.sendMessage(from, { text: "No participants found." }, { quoted: m });

      }

      // Send message with hidden mentions

      return sock.sendMessage(from, { text: message, mentions }, { quoted: m });

    } catch (e) {

      return sock.sendMessage(

        from,

        { text: `❌ Failed: ${e?.message || e}` },

        { quoted: m }

      );

    }

  },

};