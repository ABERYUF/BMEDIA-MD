export default {
  name: "uppercase",
  aliases: [],
  category: "TOOLS",
  description: "Uppercase text.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ uppercase executed.` }, { quoted: m });
  }
};
