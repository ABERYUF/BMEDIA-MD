export default {
  name: "report",
  aliases: [],
  category: "TOOLS",
  description: "Report an issue to owner.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ report executed.` }, { quoted: m });
  }
};
