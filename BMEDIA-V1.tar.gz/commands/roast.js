export default {
  name: "roast",
  aliases: [],
  category: "FUN",
  description: "Light roast (playful).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ roast executed.` }, { quoted: m });
  }
};
