export default {
  name: "count",
  aliases: [],
  category: "TOOLS",
  description: "Count words/characters.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ count executed.` }, { quoted: m });
  }
};
