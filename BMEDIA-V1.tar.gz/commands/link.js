export default {
  name: "link",
  aliases: [],
  category: "GROUP",
  description: "Get group invite link (admins only).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ link executed.` }, { quoted: m });
  }
};
