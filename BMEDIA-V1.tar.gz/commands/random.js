export default {
  name: "random",
  aliases: [],
  category: "FUN",
  description: "Random number between a and b.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ random executed.` }, { quoted: m });
  }
};
