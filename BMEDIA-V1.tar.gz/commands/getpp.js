export default {
  name: "getpp",
  aliases: [],
  category: "MEDIA",
  description: "Get profile picture of mentioned/replied user.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ getpp executed.` }, { quoted: m });
  }
};
