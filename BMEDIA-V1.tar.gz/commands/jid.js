export default {
  name: "jid",
  aliases: [],
  category: "TOOLS",
  description: "Show JID info.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ jid executed.` }, { quoted: m });
  }
};
