import fs from "fs";

import path from "path";

import { pathToFileURL } from "url";

const COMMANDS_DIR = path.resolve(process.cwd(), "commands");

const bold = (s) => `*${s}*`;

function listCommandFiles() {

  if (!fs.existsSync(COMMANDS_DIR)) return [];

  return fs

    .readdirSync(COMMANDS_DIR)

    .filter((f) => f.endsWith(".js") && !f.startsWith("_"));

}

async function loadAllCommands() {

  const files = listCommandFiles();

  const items = [];

  for (const f of files) {

    const full = path.join(COMMANDS_DIR, f);

    const bust = fs.statSync(full).mtimeMs;

    const url = pathToFileURL(full).href + `?v=${bust}`;

    try {

      const mod = await import(url);

      const cmd = mod?.default;

      if (!cmd?.name || typeof cmd.execute !== "function") continue;

      items.push(cmd);

    } catch {}

  }

  const seen = new Set();

  const uniq = [];

  for (const c of items) {

    const k = String(c.name).toLowerCase();

    if (seen.has(k)) continue;

    seen.add(k);

    uniq.push(c);

  }

  return uniq;

}

export default {

  name: "menu",

  aliases: ["help", "commands"],

  category: "INFO",

  description: "Show available commands grouped by category.",

  async execute(ctx) {

    const { sock, m, from } = ctx;

    const t0 = Date.now();

    const BOT_NAME = (process.env.BOT_NAME || ctx.botName || "BOT").trim();

    const PREFIX = (process.env.PREFIX || ctx.prefix || "!").trim();

    const AUTHOR = (process.env.AUTHOR || "Unknown").trim();

    const MODE = (process.env.BOT_MODE || "Public").trim();

    const userName =

      (m?.pushName && String(m.pushName).trim()) ||

      (ctx.sender ? String(ctx.sender).split("@")[0] : "User");

    const cmds = await loadAllCommands();

    const groups = new Map();

    for (const c of cmds) {

      const cat = String(c.category || "MISC").toUpperCase();

      if (!groups.has(cat)) groups.set(cat, []);

      groups.get(cat).push(c);

    }

    const cats = [...groups.keys()].sort((a, b) => a.localeCompare(b));

    for (const cat of cats) {

      groups.get(cat).sort((a, b) => String(a.name).localeCompare(String(b.name)));

    }

    const speed = (Date.now() - t0).toFixed(2);

    const lines = [];

    lines.push("┌──────────────────");

    lines.push(`│ ${bold(BOT_NAME)} BOT MENU`);

    lines.push("└──────────────────");

    lines.push("");

    lines.push("┌──────────────────");

    lines.push(`│ ${bold("BOT INFORMATION:")}`);

    lines.push(`│ ${bold("USERS:")} ${userName}`);

    lines.push(`│ ${bold("MODE:")} ${MODE}`);

    lines.push(`│ ${bold("PREFIX:")} [ ${PREFIX} ]`);

    lines.push(`│ ${bold("AUTHOR:")} ${bold(AUTHOR)}`);

    lines.push(`│ ${bold("SPEED:")} ${speed}ms`);

    lines.push("└──────────────────");

    for (const cat of cats) {

      lines.push("");

      lines.push("┌──────────────────");

      lines.push(`│ ${bold(`「 ${cat} 」`)}`);

      lines.push("├──────────────────");

      for (const c of groups.get(cat)) lines.push(`│ ★ ${PREFIX}${c.name}`);

      lines.push("└──────────────────");

    }

    // ✅ Footer text (NO borders)

    lines.push("");
      
  const CHANNEL_URL = (process.env.CHANNEL_URL || "").trim();

const CHANNEL_NAME = (process.env.CHANNEL_NAME || "OUR CHANNEL").trim();

lines.push("");

lines.push(`> ${bold("POWERED BY BMEDIA")}`);

lines.push("");
      
if (CHANNEL_URL) {


  lines.push(CHANNEL_URL);

}

    const caption = lines.join("\n");

    // ✅ Send logo image at the top (assets/logo.jpg) with the menu as caption

    const logoPath = path.resolve(process.cwd(), "assets", "logo.png");

    if (fs.existsSync(logoPath)) {

      const buffer = fs.readFileSync(logoPath);

      return sock.sendMessage(from, { image: buffer, caption }, { quoted: m });

    }

    // fallback (if logo missing)

    return sock.sendMessage(from, { text: caption }, { quoted: m });

  },

};