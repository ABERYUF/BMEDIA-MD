// commands/vv.js (ESM)

// Usage: reply to a view-once image/video with: !vv

// It will re-send the media as normal (not view-once).

import baileysModule from "@whiskeysockets/baileys";

const baileys = baileysModule.default || baileysModule;

const { downloadContentFromMessage } = baileys;

async function streamToBuffer(stream) {

  const chunks = [];

  for await (const chunk of stream) chunks.push(chunk);

  return Buffer.concat(chunks);

}

function unwrapViewOnce(msg) {

  // Supports different Baileys message wrappers

  // viewOnceMessage / viewOnceMessageV2 / viewOnceMessageV2Extension

  if (!msg) return null;

  const v1 = msg.viewOnceMessage?.message;

  if (v1) return v1;

  const v2 = msg.viewOnceMessageV2?.message;

  if (v2) return v2;

  const v2e = msg.viewOnceMessageV2Extension?.message;

  if (v2e) return v2e;

  return null;

}

function getQuotedMessage(m) {

  const ctx = m?.message?.extendedTextMessage?.contextInfo;

  return ctx?.quotedMessage || null;

}

function getQuotedType(qmsg) {

  if (!qmsg) return null;

  if (qmsg.imageMessage) return "image";

  if (qmsg.videoMessage) return "video";

  return null;

}

function getCaption(qmsg) {

  return (

    qmsg?.imageMessage?.caption ||

    qmsg?.videoMessage?.caption ||

    ""

  );

}

export default {

  name: "vv",

  aliases: ["viewonce", "rvo", "reveal"],

  category: "TOOLS",

  description: "Reveal and resend view-once image/video (reply to the view-once message).",

  async execute(ctx) {

    const { sock, m, from, prefix } = ctx;

    try {

      const quoted = getQuotedMessage(m);

      if (!quoted) {

        return sock.sendMessage(

          from,

          { text: `Reply to a view-once image/video with ${prefix}vv` },

          { quoted: m }

        );

      }

      // If it's wrapped as view-once, unwrap to the inner message

      const inner = unwrapViewOnce(quoted) || quoted;

      const type = getQuotedType(inner);

      if (!type) {

        return sock.sendMessage(

          from,

          { text: "❌ That reply is not a view-once image/video." },

          { quoted: m }

        );

      }

      const mediaMsg = type === "image" ? inner.imageMessage : inner.videoMessage;

      // Download media

      const stream = await downloadContentFromMessage(mediaMsg, type);

      const buffer = await streamToBuffer(stream);

      const caption = getCaption(inner);

      // Re-send as normal media (NOT view-once)

      if (type === "image") {

        return sock.sendMessage(

          from,

          { image: buffer, caption: caption || "✅ View-once revealed" },

          { quoted: m }

        );

      }

      return sock.sendMessage(

        from,

        { video: buffer, caption: caption || "✅ View-once revealed" },

        { quoted: m }

      );

    } catch (e) {

      return sock.sendMessage(

        from,

        { text: `❌ Failed: ${e?.message || e}` },

        { quoted: m }

      );

    }

  },

};