export default {
  name: "lowercase",
  aliases: [],
  category: "TOOLS",
  description: "Lowercase text.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ lowercase executed.` }, { quoted: m });
  }
};
