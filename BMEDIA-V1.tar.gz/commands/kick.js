export default {
  name: "kick",
  aliases: [],
  category: "GROUP",
  description: "Remove a member (admins only, bot admin).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ kick executed.` }, { quoted: m });
  }
};
