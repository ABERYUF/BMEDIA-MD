export default {
  name: "antispam",
  aliases: [],
  category: "GROUP",
  description: "Toggle anti-spam (placeholder).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `⚙️ Placeholder command in this pack. Tell me what API/feature you want and I’ll wire it properly.` }, { quoted: m });
  }
};
