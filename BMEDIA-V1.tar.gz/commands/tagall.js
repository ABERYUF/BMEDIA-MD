// commands/tagall.js (ESM)

// Usage: !tagall <optional message>

// Mentions all members in the group (no admin required).

// Splits mentions into chunks to avoid WhatsApp limits.

function chunk(arr, size) {

  const out = [];

  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));

  return out;

}

function numFromJid(jid) {

  return String(jid || "").split("@")[0];

}

export default {

  name: "tagall",

  aliases: ["everyone", "alltag", "mentionall"],

  category: "GROUP",

  description: "Mention all group members (no admin required).",

  async execute(ctx) {

    const { sock, m, from, args, prefix } = ctx;

    if (!from?.endsWith("@g.us")) {

      return sock.sendMessage(from, { text: "This command works in groups only." }, { quoted: m });

    }

    const text = (args || []).join(" ").trim();

    const header = text ? `📢 *Tag All*\n${text}\n\n` : "📢 *Tag All*\n\n";

    try {

      const meta = await sock.groupMetadata(from);

      const participants = (meta?.participants || []).map((p) => p.id).filter(Boolean);

      if (!participants.length) {

        return sock.sendMessage(from, { text: "No participants found." }, { quoted: m });

      }

      // WhatsApp can be picky with too many mentions; chunk to be safe.

      // 40–60 is generally safe; keep 40 for stability.

      const batches = chunk(participants, 40);

      for (let i = 0; i < batches.length; i++) {

        const batch = batches[i];

        // Build @mentions line (WhatsApp renders mentions from "mentions" array)

        const tagsLine = batch.map((jid) => `@${numFromJid(jid)}`).join(" ");

        const msgText =

          (i === 0 ? header : "") +

          tagsLine +

          (batches.length > 1 ? `\n\n(${i + 1}/${batches.length})` : "");

        await sock.sendMessage(

          from,

          { text: msgText, mentions: batch },

          { quoted: i === 0 ? m : undefined }

        );

      }

    } catch (e) {

      return sock.sendMessage(

        from,

        { text: `❌ Failed: ${e?.message || e}\nTry again.` },

        { quoted: m }

      );

    }

  },

};