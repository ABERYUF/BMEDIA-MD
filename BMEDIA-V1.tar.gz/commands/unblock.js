export default {
  name: "unblock",
  aliases: [],
  category: "OWNER",
  description: "Unblock user (owner).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ unblock executed.` }, { quoted: m });
  }
};
