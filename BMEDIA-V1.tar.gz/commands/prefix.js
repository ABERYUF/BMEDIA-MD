export default {
  name: "prefix",
  aliases: [],
  category: "INFO",
  description: "Show current prefix.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ prefix executed.` }, { quoted: m });
  }
};
