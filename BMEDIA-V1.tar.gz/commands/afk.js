export default {
  name: "afk",
  aliases: [],
  category: "TOOLS",
  description: "Set AFK status.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ afk executed.` }, { quoted: m });
  }
};
