export default {
  name: "unban",
  aliases: [],
  category: "OWNER",
  description: "Unban a user (owner).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ unban executed.` }, { quoted: m });
  }
};
