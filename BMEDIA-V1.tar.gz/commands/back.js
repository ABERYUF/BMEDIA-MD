export default {
  name: "back",
  aliases: [],
  category: "TOOLS",
  description: "Remove AFK status.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ back executed.` }, { quoted: m });
  }
};
