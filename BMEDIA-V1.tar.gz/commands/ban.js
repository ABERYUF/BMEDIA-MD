export default {
  name: "ban",
  aliases: [],
  category: "OWNER",
  description: "Ban a user from using bot (owner).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ ban executed.` }, { quoted: m });
  }
};
