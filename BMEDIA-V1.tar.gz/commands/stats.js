export default {
  name: "stats",
  aliases: [],
  category: "INFO",
  description: "Show command stats (in-memory).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ stats executed.` }, { quoted: m });
  }
};
