export default {
  name: "cleartmp",
  aliases: [],
  category: "OWNER",
  description: "Clear temp/cache files (owner).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ cleartmp executed.` }, { quoted: m });
  }
};
