export default {
  name: "invite",
  aliases: [],
  category: "GROUP",
  description: "Invite a number to group (admins only).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ invite executed.` }, { quoted: m });
  }
};
