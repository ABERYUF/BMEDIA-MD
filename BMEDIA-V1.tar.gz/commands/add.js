export default {
  name: "add",
  aliases: [],
  category: "GROUP",
  description: "Add a member by number (admins only, bot admin).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ add executed.` }, { quoted: m });
  }
};
