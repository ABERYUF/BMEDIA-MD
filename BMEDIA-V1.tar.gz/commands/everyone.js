export default {
  name: "everyone",
  aliases: [],
  category: "GROUP",
  description: "Tag all (alias).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ everyone executed.` }, { quoted: m });
  }
};
