export default {
  name: "antilink",
  aliases: [],
  category: "GROUP",
  description: "Enable/disable anti-link (admins only).",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ antilink executed.` }, { quoted: m });
  }
};
