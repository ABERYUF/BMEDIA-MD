export default {
  name: "about",
  aliases: [],
  category: "INFO",
  description: "About the bot.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ about executed.` }, { quoted: m });
  }
};
