export default {
  name: "pingall",
  aliases: [],
  category: "GROUP",
  description: "Alias of tagall.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ pingall executed.` }, { quoted: m });
  }
};
