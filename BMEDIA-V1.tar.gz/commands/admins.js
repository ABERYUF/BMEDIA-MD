// commands/tagadmins.js (ESM)

// Usage: !tagadmins <optional message>

// Mentions all group admins (no admin required).

function numFromJid(jid) {

  return String(jid || "").split("@")[0];

}

export default {

  name: "admins",

  aliases: ["tagadmin", "mentionadmins"],

  category: "GROUP",

  description: "Mention all group admins.",

  async execute(ctx) {

    const { sock, m, from, args } = ctx;

    if (!from?.endsWith("@g.us")) {

      return sock.sendMessage(from, { text: "This command works in groups only." }, { quoted: m });

    }

    const note = (args || []).join(" ").trim();

    try {

      const meta = await sock.groupMetadata(from);

      const participants = meta?.participants || [];

      const admins = participants

        .filter((p) => p.admin === "admin" || p.admin === "superadmin")

        .map((p) => p.id)

        .filter(Boolean);

      if (!admins.length) {

        return sock.sendMessage(from, { text: "No admins found in this group." }, { quoted: m });

      }

      const adminTags = admins.map((jid) => `@${numFromJid(jid)}`).join(" ");

      const text =

        `🛡️ *Group Admins*` +

        (note ? `\n${note}` : "") +

        `\n\n${adminTags}`;

      return sock.sendMessage(from, { text, mentions: admins }, { quoted: m });

    } catch (e) {

      return sock.sendMessage(

        from,

        { text: `❌ Failed: ${e?.message || e}` },

        { quoted: m }

      );

    }

  },

};