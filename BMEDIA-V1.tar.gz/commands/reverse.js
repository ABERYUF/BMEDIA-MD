export default {
  name: "reverse",
  aliases: [],
  category: "TOOLS",
  description: "Reverse text.",
  async execute(ctx) {
    const { sock, m, from } = ctx;
    return sock.sendMessage(from, { text: `✅ reverse executed.` }, { quoted: m });
  }
};
